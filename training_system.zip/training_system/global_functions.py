from tkinter import messagebox

def on_click(title, message):
    messagebox.showerror(title, message)