class user():
    def __init__(self,id,login,name,surname,mail,number,password,type):
        self.id=id
        self.login=login
        self.name=name
        self.surname=surname
        self.mail=mail
        self.number=number
        self.password=password
        self.type=type